export interface AddressInterface {
    streetAddress?: string;
    city?: string;
    state?: string;
    zipCode?: string;
}