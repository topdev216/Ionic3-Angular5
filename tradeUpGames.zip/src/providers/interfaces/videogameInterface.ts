export interface VideogameInterface {
    title?: string;
    releaseDate?: string;
    genre?: string;
    platform?: string;
    esrbRating?:string;
    coverPhoto?: string;
    type?:string;
}